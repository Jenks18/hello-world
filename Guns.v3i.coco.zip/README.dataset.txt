# Guns > 2023-05-29 10:25pm
https://universe.roboflow.com/testing-nkiaz/guns-iuybs

Provided by a Roboflow user
License: CC BY 4.0

